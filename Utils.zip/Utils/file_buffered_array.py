import os
import numpy as np


class FileBufferedArray:
    def __init__(self, path, shape, dtype):
        self.file_exists = os.path.isfile(path)
        if self.file_exists:
            self.memmap = np.memmap(path, dtype="uint16", mode="r+", shape=shape)
            self.buffered = True
        else:
            self.memmap = np.memmap(path, dtype=dtype, mode="w+", shape=shape)
            self.memmap.flush()
            self.buffered = False