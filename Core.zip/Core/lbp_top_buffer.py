import numpy as np
import os.path

from core.lbp_top_extractor import LBPTopExtractor


class LBPTopBuffer:
    def __init__(self, video_capture, lbp_top_radius=1, lbp_top_n_points=8, is_uniform=True):
        self.video_capture = video_capture
        self.lbp_top_radius = lbp_top_radius
        self.lbp_top_n_points = lbp_top_n_points
        self.is_uniform = is_uniform
        self.extractor = LBPTopExtractor(self.lbp_top_radius,
                                         self.lbp_top_n_points, is_uniform)
        self.lbp_top_xy_buffer = None
        self.lbp_top_xt_buffer = None
        self.lbp_top_yt_buffer = None

    def load_buffers(self, progress_callback):
        print('Generating LBPTOP features...')
        all_files_exist = True
        xy_xt_yt = ("xy", "xt", "yt")
        xy_xt_yt_buffers = [None, None, None]
        for index, plane in enumerate(xy_xt_yt):
            file_name = "./buffers/%s-%d-%d-%d-lbp_top_%s.dat" % (
                self.video_capture.video_id, self.lbp_top_radius,
                self.lbp_top_n_points, int(self.is_uniform), plane)
            if (not os.path.isfile(file_name)):
                all_files_exist = False
                np.memmap(
                    file_name,
                    dtype="uint16",
                    mode="w+",
                    shape=(
                        self.video_capture.frame_count - self.lbp_top_radius * 2,
                        self.video_capture.height - self.lbp_top_radius * 2,
                        self.video_capture.width - self.lbp_top_radius * 2,
                    ),
                ).flush()

            xy_xt_yt_buffers[index] = np.memmap(
                file_name,
                dtype="uint16",
                mode="r+",
                shape=(
                    self.video_capture.frame_count - self.lbp_top_radius * 2,
                    self.video_capture.height - self.lbp_top_radius * 2,
                    self.video_capture.width - self.lbp_top_radius * 2,
                ),
            )

        self.lbp_top_xy_buffer = xy_xt_yt_buffers[0]
        self.lbp_top_xt_buffer = xy_xt_yt_buffers[1]
        self.lbp_top_yt_buffer = xy_xt_yt_buffers[2]

        if (not all_files_exist):
            progress_callback(0, 100)
            self.extractor.compute_lbp_3d_image(
                self.video_capture.frame_buffer.memmap, self.lbp_top_xy_buffer,
                self.lbp_top_xt_buffer, self.lbp_top_yt_buffer)
        
        self.num_patterns = (max(self.lbp_top_xy_buffer.max(),
                                 self.lbp_top_xt_buffer.max(),
                                 self.lbp_top_yt_buffer.max()) + 1)

        self.num_patterns_max = self.num_patterns * 3
        print("Generated LBPTOP features!")

        self.lbp_top_xy_buffer.flush()

        progress_callback(100, 100)

    def get_lbp_top_hist(self, from_, to):
        from_ = max(1, from_)
        to = min(self.video_capture.frame_count - 1, to)

        if from_ - to <= 0:
            if to == 1:
                to += 1
            elif from_ == self.video_capture.frame_count - 1:
                from_ -= 1

        xy_patterns = self.lbp_top_xy_buffer[from_ - 1:to - 1].ravel()
        xt_patterns = self.lbp_top_xt_buffer[from_ - 1:to -
                                             1].ravel() + self.num_patterns
        yt_patterns = self.lbp_top_yt_buffer[from_ - 1:to -
                                             1].ravel() + self.num_patterns * 2

        return np.concatenate((xy_patterns, xt_patterns, yt_patterns))

    def get_lbp_top_hist_for_rect_coord(self, from_, to, coords):
        from_ = max(1, from_)
        to = min(self.video_capture.frame_count - 1, to)

        if from_ - to <= 0:
            if to == 1:
                to += 1
            elif from_ == self.video_capture.frame_count - 1:
                from_ -= 1

        xy_patterns = []
        xt_patterns = []
        yt_patterns = []
        for frame_index in range(from_, to):
            coord_left_top = coords[frame_index][0]
            coord_right_bottom = coords[frame_index][1]
            xy_patterns.extend(self.lbp_top_xy_buffer[frame_index - 1, coord_left_top[1]
                               : coord_right_bottom[1], coord_left_top[0]: coord_right_bottom[0]].ravel())
            xt_patterns.extend(self.lbp_top_xt_buffer[frame_index - 1, coord_left_top[1]: coord_right_bottom[1],
                               coord_left_top[0]: coord_right_bottom[0]].ravel() + self.num_patterns)
            yt_patterns.extend(self.lbp_top_yt_buffer[frame_index - 1, coord_left_top[1]: coord_right_bottom[1],
                               coord_left_top[0]: coord_right_bottom[0]].ravel() + self.num_patterns * 2)
        
        return np.concatenate((xy_patterns, xt_patterns, yt_patterns))
