from threading import Thread
from pandas import DataFrame
from core.lbp_buffer import LBPBuffer
from core.lbp_top_buffer import LBPTopBuffer
from core.video_capture import VideoCapture
from core.utils import binify

from ui.components.video_list import VideoList

class DataSetGenerator:
    def __init__(self, video_list: VideoList, app_instance):
        self.video_list = video_list
        self.input_data_frame: DataFrame = self.video_list.data_frame
        self.app_instance = app_instance
        self.lbp_top_dataset = []
        self.lbp_dataset = []

    def generate_lbp_top_dataset(self):
        Thread(target=self._generate_lbp_top_dataset).start()

    def generate_lbp_dataset(self):
        Thread(target=self._generate_lbp_dataset).start()

    def _generate_lbp_top_dataset(self):
        for index, row in self.input_data_frame.iterrows():
            # Doing this for each video in other words, for each row in csv
            self.video_list.select_item_by_index(index)
            self.app_instance.load_video_capture(wait=True)
            self.app_instance.load_lbp_top_features(wait=True)
            self.app_instance.generate_lbp_top_histogram_sequence(wait=True)
            current_item = self.video_list.get_current_item()

            video_capture: VideoCapture = self.app_instance.video_capture
            lbp_top_histogram_sequence = video_capture.lbp_top_histogram_sequence
            apex_frame_index = row["ApexFrame"]
            feature_vector = lbp_top_histogram_sequence.get_histogram(apex_frame_index)
            # estimated_emotion = row["Estimated Emotion"]
            data_row = feature_vector.tolist()
            for field in row.keys():
                print(field)
                data_row.append(row[field])
            
            data_row.append(current_item['path'])
            self.lbp_top_dataset.append(data_row)
        self.save("./test/lbp_top_dataset.pkl", self.lbp_top_dataset)


    def _generate_lbp_dataset(self):
        for index, row in self.input_data_frame.iterrows():
            # Doing this for each video in other words, for each row in csv
            self.video_list.select_item_by_index(index)
            self.app_instance.load_video_capture(wait=True)
            self.app_instance.load_lbp_features(wait=True)
            video_capture: VideoCapture = self.app_instance.video_capture
            lbp_buffer: LBPBuffer = video_capture.lbp_buffer
            apex_frame_index = row["ApexFrame"]
            feature_vector = lbp_buffer.get_lbp_hist_face(apex_frame_index)
            estimated_emotion = row["Estimated Emotion"]
            data_row = binify(feature_vector)
            data_row.append(estimated_emotion)
            self.lbp_dataset.append(data_row)
        self.save("./test/lbp_dataset.pkl", self.lbp_dataset)
    
    def save(self, filename, dataset):
        df = DataFrame(dataset)
        df.to_pickle(filename)