from core.lbp_top_buffer import LBPTopBuffer
from core.utils import binify
from utils.file_buffered_array import FileBufferedArray


class LBPTOPHistogramSequence:
    def __init__(self, video_capture, interval_size, offset):
        self.interval_size = interval_size
        self.offset = offset

        self.video_capture = video_capture
        self.lbp_top_buffer: LBPTopBuffer = self.video_capture.lbp_top_buffer

        histogram_sequence_buffer_path = "./buffers/%s-%d-%d-%d-lbp_top-hist-seq-%d-%d.dat" % (
            self.video_capture.video_id, self.lbp_top_buffer.lbp_top_radius,
            self.lbp_top_buffer.lbp_top_n_points, int(self.lbp_top_buffer.is_uniform), self.interval_size, self.offset)
        
        self.num_possible_patterns = self.lbp_top_buffer.num_patterns_max

        self.lbp_top_histogram_buffer = FileBufferedArray(histogram_sequence_buffer_path, (self.video_capture.frame_count, self.num_possible_patterns), dtype="uint32")

    def generate(self, progress_callback):
        print("Generating LBPTOP Histogram Sequence...")
        if self.lbp_top_histogram_buffer.buffered:
            print("Pre-Buffered data found. Generated Histogram Sequence!")
            return
        
        frame_count = self.video_capture.frame_count
        for frame_index in range(frame_count):
            lower_bound = frame_index - self.interval_size + self.offset + 1
            upper_bound = frame_index + self.offset + 1

            histogram_values = self.lbp_top_buffer.get_lbp_top_hist_for_rect_coord(
                lower_bound, upper_bound, self.video_capture.face_coordinates_buffer.memmap).tolist()
            self.lbp_top_histogram_buffer.memmap[frame_index] = binify(histogram_values)

            progress_callback(frame_index, frame_count - 1)

        self.lbp_top_histogram_buffer.buffered = True
        self.lbp_top_histogram_buffer.memmap.flush()
        print("Generated LBPTOP Histogram Sequence!")

    def get_histogram(self, frame_index):
        return self.lbp_top_histogram_buffer.memmap[frame_index]
