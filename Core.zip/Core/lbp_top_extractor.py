from bob.ip.base import LBP, LBPTop

class LBPTopExtractor:
    def __init__(self, radius, n_points, uniform = True):
        self.radius = radius
        self.n_points = n_points
        lbp_xy = LBP(n_points, radius, uniform = uniform)
        lbp_xt = LBP(n_points, radius, uniform = uniform)
        lbp_yt = LBP(n_points, radius, uniform = uniform)
        self.lbptop = LBPTop(lbp_xy, lbp_xt, lbp_yt)

    def compute_lbp_3d_image(self, video, output_xy, output_xt, output_yt):
        self.lbptop(video, output_xy, output_xt, output_yt)
        return