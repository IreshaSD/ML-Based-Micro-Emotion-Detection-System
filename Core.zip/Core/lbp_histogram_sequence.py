class LBPHistogramSequence:
    def __init__(self):
        pass