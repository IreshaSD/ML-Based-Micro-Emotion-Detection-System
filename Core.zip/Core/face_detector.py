import dlib

class FaceDetector:
    def __init__(self):
        self.detector = dlib.get_frontal_face_detector()

    def get_face_coordinates(self, gray_image):
        faces = self.detector(gray_image)
        face_coordinates = faces[0]
        x1, y1 = face_coordinates.left(), face_coordinates.top()
        x2, y2 = face_coordinates.right(), face_coordinates.bottom()
        return [(x1, y1), (x2, y2)]