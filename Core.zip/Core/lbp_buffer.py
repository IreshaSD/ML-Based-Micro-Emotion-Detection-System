import numpy as np
import os.path
from core.face_detector import FaceDetector
from core.lbp_extractor import LBPExtractor


class LBPBuffer:
    def __init__(self, video_capture, lbp_radius=1, lbp_method = "uniform"):
        self.lbp_radius = lbp_radius
        self.lbp_method = lbp_method
        self.extractor = LBPExtractor(lbp_radius, lbp_method)
        self.video_capture = video_capture

    def get_lbp_image(self, frame_no):
        if not np.count_nonzero(self.lbp_buffer[frame_no]):
            self.lbp_buffer[frame_no] = self.extractor.compute_lbp_image(
                self.video_capture.get_frame_by_index(frame_no))
        print(self.lbp_buffer[frame_no])
        return self.lbp_buffer[frame_no]
    
    def get_lbp_hist(self, frame_no):
        return list(map(int, self.get_lbp_image(frame_no).ravel()))
    
    def get_lbp_hist_face(self, frame_no):
        face_detector = FaceDetector()
        frame = self.video_capture.get_frame_by_index(frame_no)
        face_coordinates = face_detector.get_face_coordinates(frame)
        lbp_image = self.get_lbp_image(frame_no)
        x1, y1 = face_coordinates.left(), face_coordinates.top()
        x2, y2 = face_coordinates.right(), face_coordinates.bottom()
        lbp_face_image = lbp_image[y1:y2, x1:x2]
        return list(map(int, lbp_face_image.ravel()))

    def get_lbp_hist_face_interval(self, from_, to):
        hist = []
        for frame_index in range(from_, to):
            hist.append(self.get_lbp_hist_face(frame_index))
        return hist

    def load_buffers(self, progress_callback):
        print("Generating LBP features...")
        file_name = "./buffers/%s-%d-%s-lbp.dat" % (
            self.video_capture.video_id, self.lbp_radius, self.lbp_method)

        file_existed = True
        if (not os.path.isfile(file_name)):
            file_existed = False
            np.memmap(
                file_name,
                dtype="float32",
                mode="w+",
                shape=(
                    self.video_capture.frame_count,
                    self.video_capture.height,
                    self.video_capture.width,
                ),
            ).flush()

        self.lbp_buffer = np.memmap(
            file_name,
            dtype="float32",
            mode="r+",
            shape=(
                self.video_capture.frame_count,
                self.video_capture.height,
                self.video_capture.width,
            ),
        )

        if (not file_existed):
            progress_callback(0, self.video_capture.frame_count - 1)
            for frame_no in range(self.video_capture.frame_count):
                self.lbp_buffer[frame_no] = self.extractor.compute_lbp_image(
                    self.video_capture.get_frame_by_index(frame_no))
                progress_callback(frame_no, self.video_capture.frame_count - 1)
        
        self.lbp_buffer.flush()
        print("Generated LBP features!")
        progress_callback(100, 100)