import hashlib
import tkinter as tk

def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def binify(list_):
    result = [0 for i in range(max(list_) + 1)]
    for i in list_:
        result[i] += 1
    return result

def update_option_menu(var, option_menu, new_choices):
    # Reset var and delete all old options
    option_menu['menu'].delete(0, 'end')

    # Insert list of new options (tk._setit hooks them up to var)
    for choice in new_choices:
        option_menu['menu'].add_command(label=choice, command=tk._setit(var, choice))
