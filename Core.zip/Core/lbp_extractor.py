from skimage.feature import local_binary_pattern

class LBPExtractor:
    def __init__(self, radius, method):
        self.radius = radius
        self.n_points = 8 * radius
        self.method = method
        self.lbp_image = None

    def compute_lbp_image(self, image):
        self.lbp_image = local_binary_pattern(
            image, self.n_points, self.radius, self.method
        )
        return self.lbp_image