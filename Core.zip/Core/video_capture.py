import cv2
from threading import Thread

from pandas.core.frame import DataFrame
from core.face_detector import FaceDetector

from core.lbp_buffer import LBPBuffer
from core.lbp_top_buffer import LBPTopBuffer
from core.lbp_top_histogram_sequence import LBPTOPHistogramSequence
from core.utils import md5
from utils.file_buffered_array import FileBufferedArray


class VideoCapture:
    def __init__(self, video_source, list_item, app_instance):
        self.app_instance = app_instance
        self.list_item = list_item
        self.test_results = None
        self.vid = cv2.VideoCapture(video_source)
        if not self.vid.isOpened():
            raise ValueError("Unable to open the video source", video_source)

        self.width = int(self.vid.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.height = int(self.vid.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.frame_count = int(self.vid.get(cv2.CAP_PROP_FRAME_COUNT))
        self.current_frame = 0
        self.video_id = md5(video_source)

        frame_buffer_path = "./buffers/%s-frame.dat" % (self.video_id)
        self.frame_buffer = FileBufferedArray(
            frame_buffer_path, (self.frame_count, self.height, self.width), "uint16")

        face_coordinates_buffer_path = "./buffers/%s-frame-face-coord.dat" % (
            self.video_id)
        self.face_coordinates_buffer = FileBufferedArray(
            face_coordinates_buffer_path, (self.frame_count, 2, 2), "uint16")

        self.on_update_subscriptions = {}

    def buffer_frames(self, progress_callback, wait=False):
        if not wait:
            Thread(target=self._buffer_frames,
                   args=(progress_callback, )).start()
        else:
            self._buffer_frames(progress_callback)

    def generate_lbp_top_features(self, lbp_top_radius, lbp_top_n_points, lbp_top_is_uniform, progress_callback, wait=False):
        self.lbp_top_buffer = LBPTopBuffer(self, lbp_top_radius,
                                           lbp_top_n_points,
                                           lbp_top_is_uniform)
        if not wait:
            Thread(target=self.lbp_top_buffer.load_buffers,
                   args=(progress_callback, )).start()
        else:
            self.lbp_top_buffer.load_buffers(progress_callback)

    def generate_lbp_features(self, lbp_radius, lbp_method, progress_callback, wait=False):
        self.lbp_buffer = LBPBuffer(self, lbp_radius, lbp_method)
        if not wait:
            Thread(target=self.lbp_buffer.load_buffers,
                   args=(progress_callback, )).start()
        else:
            self.lbp_buffer.load_buffers(progress_callback)

    def generate_lbp_top_histogram_sequence(self, lbp_top_interval, progress_callback, wait=False):
        self.lbp_top_histogram_sequence = LBPTOPHistogramSequence(
            self, lbp_top_interval, lbp_top_interval // 2)

        if not wait:
            Thread(target=self.lbp_top_histogram_sequence.generate,
                   args=(progress_callback, )).start()
        else:
            self.lbp_top_histogram_sequence.generate(progress_callback)

    def generate_test_results_for_current_video(self, progress_callback):
        Thread(target=self._generate_test_results_for_current_video,
               args=(progress_callback,)).start()

    def get_lbp_top_hist(self):
        return self.lbp_top_histogram_sequence.get_histogram(self.current_frame)

    def _get_frame(self):
        if self.vid.isOpened():
            if self.current_frame != self.vid.get(cv2.CAP_PROP_POS_FRAMES):
                self.vid.set(cv2.CAP_PROP_POS_FRAMES, self.current_frame)
            ret, frame = self.vid.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                # self.overlay_frame_number(frame)
                # self.apply_face_mesh(frame)
                return (ret, frame)
            else:
                return (ret, None)
        else:
            return (False, None)

    def _buffer_frames(self, progress_callback):
        print("Start buffering frames from the video file...")
        if self.frame_buffer.buffered and self.face_coordinates_buffer.buffered:
            print("Pre-buffered data found. Buffering frames completed!")
            progress_callback(self.frame_count, self.frame_count)
            return

        self.current_frame = 0
        while self.current_frame < self.frame_count:
            ret, frame = self._get_frame()
            self.frame_buffer.memmap[self.current_frame] = frame
            face_detector = FaceDetector()
            if not self.face_coordinates_buffer.buffered:
                face_coordinates = face_detector.get_face_coordinates(frame)
                self.face_coordinates_buffer.memmap[self.current_frame] = face_coordinates
            progress_callback(self.current_frame, self.frame_count)
            self.current_frame += 1
        self.current_frame %= self.frame_count
        self.frame_buffer.buffered = True
        self.frame_buffer.memmap.flush()
        self.face_coordinates_buffer.buffered = True
        self.face_coordinates_buffer.memmap.flush()
        print("Buffering frames completed!")

    def get_frame_by_index(self, frame_no, update=False):
        if update:
            self.notify_on_update_subscriptions()
        return self.frame_buffer.memmap[frame_no]

    def get_face_coordinates_by_index(self, frame_no):
        return self.face_coordinates_buffer.memmap[frame_no]

    def get_lbp_image(self):
        return self.lbp_buffer.get_lbp_image(self.current_frame)

    def get_lbp_hist(self):
        return self.lbp_buffer.get_lbp_image(self.current_frame).ravel()

    def _generate_test_results_for_current_video(self, progress_callback):
        self.test_results = [None for _ in range(self.frame_count)]
        for current_point in range(self.frame_count):
            self.test_results[current_point] = self._test_point_by_index(
                current_point)
            progress_callback(current_point, self.frame_count)

    def _get_lbp_top_hist(self, interval_size):
        lower_bound = self.current_frame - interval_size + 1
        upper_bound = self.current_frame + 1
        print(lower_bound, upper_bound)
        return self.lbp_top_buffer.get_lbp_top_hist(lower_bound, upper_bound)

    def _test_point_by_index(self, index):
        model = self.app_instance.get_current_model()
        current_point_feature_vector = [self.lbp_top_histogram_sequence.get_histogram(
            index)]
        print(current_point_feature_vector)
        prediction = model.predict(current_point_feature_vector)[0]
        print(prediction)
        return prediction

    def apply_face_mesh(self, frame):
        frame, faces = self.face_mesh_detector.findFaceMesh(frame, True)
        return frame

    def notify_on_update_subscriptions(self):
        for subscription_key in self.on_update_subscriptions:
            self.on_update_subscriptions[subscription_key](self)

    def __del__(self):
        if self.vid.isOpened():
            self.vid.release()
