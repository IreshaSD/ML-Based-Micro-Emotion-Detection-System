from tkinter import Button, Entry, Label, Listbox, OptionMenu, StringVar, Toplevel
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.metrics import accuracy_score


class TrainingWindow(Toplevel):
    def __init__(self, master, app_instance):
        super().__init__(master=master)
        self.init_guy_elements()
        self.layout_guy()
        self.app_instance = app_instance
        self.dataset_generator = app_instance.dataset_generator
        self.lbp_top_X_train_origin = None
        self.lbp_top_X_test_origin = None
        self.register_input_event_handlers()

    def init_guy_elements(self):
        # Training Elements
        self.train_lbp_top_svm_btn = Button(
            self, text="LBP-TOP Train SVM")
        self.train_svm_c_label = Label(self, text="C")
        self.train_svm_c = StringVar(self, value=1.0)
        self.train_svm_c_entry = Entry(
            self, textvariable=self.train_svm_c)
        self.train_svm_kernel_label = Label(self, text="SVM Kernel")
        self.train_svm_kernel = StringVar(self, value="rbf")
        self.train_svm_kernel_drop_down = OptionMenu(
            self, self.train_svm_kernel,  "linear", "poly", "rbf", "sigmod")
        self.train_svm_degree_label = Label(self, text="Degree")
        self.train_svm_degree = StringVar(self, value="3")
        self.train_svm_degree_entry = Entry(
            self, textvariable=self.train_svm_degree)
        self.train_svm_test_data_size_label = Label(
            self, text="Test Data Size")
        self.train_svm_test_data_size = StringVar(self, value="0.2")
        self.train_svm_test_data_size_entry = Entry(
            self, textvariable=self.train_svm_test_data_size)
        self.accuracy_label = Label(self, text="Accuracy: ")
        self.accuracy_value = StringVar(self, value="0")
        self.accuracy_value_label = Label(
            self, textvariable=self.accuracy_value)

        self.training_data_list = Listbox(self, height=50, width=30)
        self.testing_data_list = Listbox(self, height=50, width=30)

    def layout_guy(self):
        # Training elements
        self.train_lbp_top_svm_btn.grid(row=0, column=0)
        self.train_svm_c_label.grid(row=0, column=1)
        self.train_svm_c_entry.grid(row=0, column=2)
        self.train_svm_kernel_label.grid(row=0, column=3)
        self.train_svm_kernel_drop_down.grid(row=0, column=4)
        self.train_svm_degree_label.grid(row=0, column=5)
        self.train_svm_degree_entry.grid(row=0, column=6)
        self.train_svm_test_data_size_label.grid(row=0, column=7)
        self.train_svm_test_data_size_entry.grid(row=0, column=8)
        self.accuracy_label.grid(row=0, column=9)
        self.accuracy_value_label.grid(row=0, column=10)
        self.training_data_list.grid(row=1, column=0, columnspan=3)
        self.testing_data_list.grid(row=1, column=3, columnspan=3)

    def register_input_event_handlers(self):
        self.train_lbp_top_svm_btn.configure(command=self.train_lbp_top_svm)

    def split_data_set(self):
        test_data_size = float(self.train_svm_test_data_size.get())
        lbp_top_X = self.lbp_top_dataset.copy(deep=True)
        lbp_top_y = self.lbp_top_dataset[self.lbp_top_dataset.columns[-2]]

        X_train, X_test, y_train, y_test = train_test_split(
            lbp_top_X, lbp_top_y, test_size=test_data_size)

        self.lbp_top_X_train = X_train.drop(X_train.columns[-7:], axis=1)
        self.lbp_top_X_test = X_test.drop(X_test.columns[-7:], axis=1)
        self.lbp_top_y_train = y_train
        self.lbp_top_y_test = y_test

        self.lbp_top_X_train_origin = X_train[X_train.columns[-7:]]
        self.lbp_top_X_test_origin = X_test[X_test.columns[-7:]]
        self.lbp_top_X_train_origin.columns = [
            'Subject', 'Filename', 'OnsetFrame', 'ApexFrame', 'OffsetFrame', 'Estimated Emotion', 'path']
        self.lbp_top_X_test_origin.columns = [
            'Subject', 'Filename', 'OnsetFrame', 'ApexFrame', 'OffsetFrame', 'Estimated Emotion', 'path']

    def fill_list_boxes(self):
        self.training_data_list.delete(0, 'end')
        for index, row in self.lbp_top_X_train_origin.iterrows():
            subject = row[self.lbp_top_X_train_origin.columns[-7]]
            episode = row[self.lbp_top_X_train_origin.columns[-6]]
            self.training_data_list.insert(index, f"{subject}_{episode}")

        self.testing_data_list.delete(0, 'end')
        for index, row in self.lbp_top_X_test_origin.iterrows():
            subject = row[self.lbp_top_X_test_origin.columns[-7]]
            episode = row[self.lbp_top_X_test_origin.columns[-6]]
            self.testing_data_list.insert(index, f"{subject}_{episode}")

    def train_lbp_top_svm(self):
        self.lbp_top_dataset = pd.DataFrame(
            self.dataset_generator.lbp_top_dataset)

        self.split_data_set()
        self.fill_list_boxes()

        C = float(self.train_svm_c_entry.get())
        svm_kernel = self.train_svm_kernel.get()
        degree = int(self.train_svm_degree.get())

        self.lbp_top_svm_model = svm.SVC(C=C, kernel=svm_kernel, degree=degree)
        self.lbp_top_svm_model.fit(self.lbp_top_X_train, self.lbp_top_y_train)
        predictions = self.lbp_top_svm_model.predict(self.lbp_top_X_test)
        score = accuracy_score(self.lbp_top_y_test, predictions)
        print(score)
        print("Accuracy =" + str(score*100)+"%")

        self.accuracy_value.set(str(score*100)+"%")
