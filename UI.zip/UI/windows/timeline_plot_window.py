from tkinter import Label, OptionMenu, StringVar, Toplevel
from tkinter.ttk import Combobox
from core.utils import update_option_menu
from ui.components.timeline_plot_canvas import TimelinePlotCanvas


class TimelinePlotWindow(Toplevel):
    def __init__(self, master, app_instance):
        super().__init__(master=master)
        self.init_gui_elements()
        self.layout_gui()
        self.app_instance = app_instance

        self.plot_markers()
        self.register_input_event_handlers()
        # self.on_feature_method_selected("LBP-TOP")

    def init_gui_elements(self):
        self.plot_canvas = TimelinePlotCanvas(self)

        self.feature_method_label = Label(self, text="Feature method")
        self.feature_method = StringVar(self, value="LBP-TOP")
        self.feature_method_drop_down = OptionMenu(
            self, self.feature_method, "LBP-TOP", "LBP", command=self.on_feature_method_selected)

        self.pattern_no_label = Label(self, text="Pattern No")
        self.pattern_no = StringVar(self, value="0")
        self.pattern_no_drop_down = Combobox(
            self, textvariable=self.pattern_no, values=["0", "1"])

    def layout_gui(self):
        self.plot_canvas.get_tk_widget().grid(row=0, column=0, columnspan=20)

        self.feature_method_label.grid(row=1, column=0)
        self.feature_method_drop_down.grid(row=1, column=2)

        self.pattern_no_label.grid(row=1, column=3)
        self.pattern_no_drop_down.grid(row=1, column=4)

    def register_input_event_handlers(self):
        self.pattern_no.trace("w", self.on_pattern_no_selected)

    def on_feature_method_selected(self, value):
        video_capture = self.app_instance.video_capture
        if value == "LBP-TOP":
            lbp_top_num_patterns = video_capture.lbp_top_buffer.num_patterns
            self.pattern_no_drop_down['values'] = [
                str(i) for i in range(lbp_top_num_patterns)]

    def on_pattern_no_selected(self, *args):
        pattern_no = int(self.pattern_no.get())
        if self.feature_method.get() == "LBP-TOP":
            self.plot_lbp_top(pattern_no)
            self.plot_markers()

    def plot_markers(self):
        video_item = self.app_instance.video_capture.list_item
        onset_index = video_item['OnsetFrame']
        apex_index = video_item['ApexFrame']
        offset_index = video_item['OffsetFrame']
        self.plot_canvas.plot_vline(onset_index)
        self.plot_canvas.plot_vline(apex_index)
        self.plot_canvas.plot_vline(offset_index)

    def plot_lbp_top(self, pattern_index):
        video_capture = self.app_instance.video_capture
        points = []
        for frame_index in range(video_capture.frame_count):
            lbp_top_histogram_sequence = video_capture.lbp_top_histogram_sequence.get_histogram(
                frame_index)
            points.append(lbp_top_histogram_sequence[pattern_index])

        self.plot_canvas.plot_line(points)
