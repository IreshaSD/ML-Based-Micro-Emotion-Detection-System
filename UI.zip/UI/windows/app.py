from tkinter import BooleanVar, Button, Entry, Label, OptionMenu, Radiobutton, Scale, StringVar, Toplevel
from tkinter.ttk import Progressbar
from tkinter.constants import HORIZONTAL
from functools import partial
from math import ceil

from ui.components.plot_canvas import PlotCanvas
from ui.components.timeline_plot_canvas import TimelinePlotCanvas
from ui.windows.plot_window import PlotWindow
from core.dataset_generator import DataSetGenerator
from ui.windows.testing_window import TestingWindow
from ui.windows.timeline_plot_window import TimelinePlotWindow
from ui.windows.training_window import TrainingWindow
from ui.components.video_canvas import VideoCanvas
from core.video_capture import VideoCapture
from ui.components.video_list import VideoList


class App:
    def __init__(self, window, window_title, video_list_csv, base_path):
        self.window = window
        self.window_title = window_title
        self.video_list_csv = video_list_csv
        self.base_path = base_path
        self.video_capture = None
        self.lbp_top_graph_window = None
        self.lbp_graph_window = None
        self.training_window = None
        self.testing_window = None
        self.timeline_plot_window = None

        # init_gui also registers the input event handlers
        self.init_gui_elements()
        self.layout_gui()
        self.dataset_generator = DataSetGenerator(self.video_list, self)
        self.register_input_event_handlers()

        # self.video_canvas.play()
        self.window.mainloop()

    def init_gui_elements(self):
        # Video ListBox
        self.video_list = VideoList(
            self.window, self.base_path, self.video_list_csv)

        # Button that load the selected video from the list to current context
        self.load_selected_video_btn = Button(
            self.window,
            text="Load Selected Video",)

        # Video Viewer
        self.video_canvas = VideoCanvas(self.window)
        self.play_pause_btn = Button(
            self.window,
            text="Play/Pause",)
        self.seekbar = Scale(
            from_=0,
            to=250,
            orient=HORIZONTAL,
            length=400,)

        # LBP-TOP Feature Generation Elements
        self.generate_lbp_top_features_btn = Button(
            self.window,
            text="Generate LBP-TOP\nfeatures",
        )
        self.lbp_top_radius_label = Label(self.window, text="Radius")
        self.lbp_top_radius = StringVar(self.window, value="1")
        self.lbp_top_radius_entry = Entry(self.window,
                                          textvariable=self.lbp_top_radius)
        self.lbp_top_n_points_label = Label(self.window, text="N Points")
        self.lbp_top_n_points = StringVar(self.window, value="8")
        self.lbp_top_n_points_entry = Entry(self.window,
                                            textvariable=self.lbp_top_n_points)
        self.lbp_top_is_uniform = BooleanVar(master=self.window, value=True)
        self.lbp_top_uniform_tick = Radiobutton(
            self.window,
            text="Uniform",
            variable=self.lbp_top_is_uniform,
            value=True,
            indicatoron=False)
        self.lbp_top_non_uniform_tick = Radiobutton(
            self.window,
            text="Non Uniform",
            variable=self.lbp_top_is_uniform,
            value=False,
            indicatoron=False)
        self.show_lbp_top_graph_btn = Button(
            self.window,
            text="Show LBP-TOP Graph",)

        # LBP Feature Generation Elements
        self.generate_lbp_features_btn = Button(
            self.window,
            text="Generate LBP\nfeatures",)
        self.lbp_radius_label = Label(self.window, text="Radius")
        self.lbp_radius = StringVar(self.window, value="1")
        self.lbp_radius_entry = Entry(self.window,
                                      textvariable=self.lbp_radius)
        self.lbp_method_label = Label(self.window, text="LBP Method")
        self.lbp_method = StringVar(self.window, value="uniform")
        self.lbp_method_drop_down = OptionMenu(self.window, self.lbp_method,
                                               "default", "uniform", "ror",
                                               "nri_uniform", "var")
        self.show_lbp_graph_btn = Button(
            self.window,
            text="Show LBP Graph",)

        # LBP-TOP Graph Generation Elements
        self.generate_lbp_top_histogram_sequence_btn = Button(
            self.window, text="Generate LBP-TOP Histogram Sequence")
        self.lbp_top_interval_label = Label(
            self.window, text="LBP-TOP Interval")
        self.lbp_top_interval = StringVar(self.window, value="30")
        self.lbp_top_interval_entry = Entry(
            self.window, textvariable=self.lbp_top_interval)

        # LBP Graph Generation Elements
        self.generate_lbp_histogram_sequence_btn = Button(
            self.window, text="Generate LBP Histogram Sequence")
        self.lbp_interval_label = Label(
            self.window, text="LBP Interval")
        self.lbp_interval = StringVar(self.window, value="30")
        self.lbp_interval_entry = Entry(
            self.window, textvariable=self.lbp_interval)

        # Dataset Generation Elements
        self.generate_lbp_top_dataset_btn = Button(
            self.window, text="Generate LBP-TOP DataSet")
        self.generate_lbp_dataset_btn = Button(self.window,
                                               text="Generate LBP DataSet")

        # Open Training Window
        self.show_training_window_btn = Button(
            self.window, text="Show Training Window")

        # Show Testing Window
        self.load_testing_data_btn = Button(
            self.window, text="Load Testing Data")
        
        # Generate Test Results Button
        self.generate_test_results_btn = Button(
            self.window, text="Generate Test Results"
        )

        # Common Progress Bar
        self.progress_bar = Progressbar(self.window,
                                        orient=HORIZONTAL,
                                        length=500,
                                        mode='determinate')

        # Show plot window button
        self.show_plot_window_btn = Button(
            self.window, text="Show Timeline Plot Window")

    def layout_gui(self):
        # Video ListBox
        self.video_list.grid(row=0, column=0, rowspan=10)

        # Button that load the selected video from the list to current context
        self.load_selected_video_btn.grid(row=8, column=1, columnspan=10)

        # Video Viewer
        self.video_canvas.grid(row=0, column=1, rowspan=8, columnspan=10)
        self.play_pause_btn.grid(row=9, column=1)
        self.seekbar.grid(row=9, column=2, pady=(0, 14))

        # LBP-TOP Feature Generation Elements
        self.generate_lbp_top_features_btn.grid(row=0, column=11)
        self.lbp_top_radius_label.grid(row=0, column=12)
        self.lbp_top_radius_entry.grid(row=0, column=13)
        self.lbp_top_n_points_label.grid(row=0, column=14)
        self.lbp_top_n_points_entry.grid(row=0, column=15)
        self.lbp_top_uniform_tick.grid(row=0, column=16)
        self.lbp_top_non_uniform_tick.grid(row=0, column=17)

        # LBP Feature Generation Elements
        self.generate_lbp_features_btn.grid(row=1, column=11)
        self.lbp_radius_label.grid(row=1, column=12)
        self.lbp_radius_entry.grid(row=1, column=13)
        self.lbp_method_label.grid(row=1, column=14)
        self.lbp_method_drop_down.grid(row=1, column=15)

        # LBP-TOP Graph Generation Elements
        self.generate_lbp_top_histogram_sequence_btn.grid(row=2, column=11)
        self.lbp_top_interval_label.grid(row=2, column=12)
        self.lbp_top_interval_entry.grid(row=2, column=13)
        self.show_lbp_top_graph_btn.grid(row=2, column=14)

        # LBP-TOP Graph Generation Elements
        self.generate_lbp_histogram_sequence_btn.grid(row=3, column=11)
        self.lbp_interval_label.grid(row=3, column=12)
        self.lbp_interval_entry.grid(row=3, column=13)
        self.show_lbp_graph_btn.grid(row=3, column=14)

        # DataSet Generation Elements
        self.generate_lbp_top_dataset_btn.grid(row=4, column=11)
        self.generate_lbp_dataset_btn.grid(row=4, column=12)

        # Show Training Window
        self.show_training_window_btn.grid(row=5, column=11)

        # Show Testing Window
        self.load_testing_data_btn.grid(row=5, column=12)

        # Generate Test Results Button
        self.generate_test_results_btn.grid(row=5, column=13)

        # Common Progress Bar
        self.progress_bar.grid(row=6, column=11, columnspan=5)

        # Show plot window button
        self.show_plot_window_btn.grid(row=20, column=5)

    def register_input_event_handlers(self):
        self.load_selected_video_btn.configure(command=self.load_video_capture)
        self.play_pause_btn.configure(command=self.play_pause)
        self.seekbar.configure(command=self.video_canvas.seek)

        self.generate_lbp_top_features_btn.configure(
            command=self.load_lbp_top_features)
        self.generate_lbp_features_btn.configure(
            command=self.load_lbp_features)

        self.generate_lbp_top_histogram_sequence_btn.configure(
            command=self.generate_lbp_top_histogram_sequence)
        self.generate_lbp_histogram_sequence_btn.configure(
            command=self.generate_lbp_histogram_sequence)

        self.show_lbp_top_graph_btn.configure(command=self.show_lbp_top_graph)
        self.show_lbp_graph_btn.configure(command=self.show_lbp_graph)

        self.generate_lbp_top_dataset_btn.configure(
            command=self.generate_lbp_top_dataset)
        self.generate_lbp_dataset_btn.configure(
            command=self.generate_lbp_dataset)

        self.show_training_window_btn.configure(
            command=self.show_training_window)
        self.load_testing_data_btn.configure(command=self.load_testing_data)
        self.generate_test_results_btn.configure(command=self.generate_test_results)
        self.show_plot_window_btn.configure(
            command=self.show_timeline_plot_window)

    def load_video_capture(self, wait=False):
        print("Load Selected Video button pressed")
        try:
            selected_video_item = self.video_list.get_current_item()
            currently_selected_video_path = selected_video_item['path']
        except Exception as ex:
            print("Please select a video first!!!")
            return

        self.video_capture = VideoCapture(
            currently_selected_video_path, selected_video_item, self)
        self.video_canvas.video_capture = self.video_capture
        self.video_capture.buffer_frames(self.update_progress_bar, wait)
        self.seekbar['to'] = self.video_capture.frame_count - 1

    def play_pause(self):
        print("Play/Pause button pressed!")
        if not self.video_capture:
            print("Please load the video first!!!")
            return
        self.video_canvas.play_pause()

    def load_lbp_top_features(self, wait=False):
        print("Generate LBPTOP features button pressed!")
        if not self.video_capture:
            print("Please load the video first!!!")
            return

        lbp_top_radius = int(self.lbp_top_radius.get())
        lbp_top_n_points = int(self.lbp_top_n_points.get())
        lbp_top_is_uniform = self.lbp_top_is_uniform.get()

        self.video_capture.generate_lbp_top_features(lbp_top_radius, lbp_top_n_points, lbp_top_is_uniform, self.update_progress_bar,
                                                     wait)

    def load_lbp_features(self, wait=False):
        print("Generate LBP features button pressed!")
        if not self.video_capture:
            print("Please load the video first!!!")
            return

        lbp_radius = int(self.lbp_radius.get())
        lbp_method = self.lbp_method.get()

        self.video_capture.generate_lbp_features(lbp_radius, lbp_method, self.update_progress_bar,
                                                 wait)

    def generate_lbp_top_histogram_sequence(self, wait=False):
        print("Generate LBP-TOP Hitogram Sequence button pressed!")
        if not self.video_capture:
            print("Please load the video first!!!")
            return
        lbp_top_interval = int(self.lbp_top_interval.get())
        self.video_capture.generate_lbp_top_histogram_sequence(
            lbp_top_interval, self.update_progress_bar, wait)

    def generate_lbp_histogram_sequence(self):
        print("Generate LBP Histogram Sequence button pressed!")

    def show_lbp_top_graph(self):
        self.lbp_top_graph_window = self._show_window(
            PlotWindow, self.lbp_top_graph_window)
        self.video_capture.on_update_subscriptions[
            PlotCanvas.PLOT_TYPE_LBP_TOP_HIST] = partial(
                self.lbp_top_graph_window.plot_canvas.update_plot,
                PlotCanvas.PLOT_TYPE_LBP_TOP_HIST)

    def show_lbp_graph(self):
        self.lbp_graph_window = self._show_window(
            PlotWindow, self.lbp_graph_window)
        self.video_capture.on_update_subscriptions[
            PlotCanvas.PLOT_TYPE_LBP_HIST] = partial(
                self.lbp_graph_window.plot_canvas.update_plot,
                PlotCanvas.PLOT_TYPE_LBP_HIST)

    def generate_lbp_top_dataset(self):
        self.dataset_generator.generate_lbp_top_dataset()

    def generate_lbp_dataset(self):
        self.dataset_generator.generate_lbp_dataset()

    def generate_test_results(self):
        self.video_capture.generate_test_results_for_current_video(self.update_progress_bar)

    def show_timeline_plot_window(self):
        self.timeline_plot_window = self._show_window(
            TimelinePlotWindow, self.timeline_plot_window, self)

    def _show_window(self, class_, window_instance, *args):
        if window_instance != None and Toplevel.winfo_exists(
                window_instance):
            return window_instance
        return class_(self.window, *args)

    def show_training_window(self):
        self.training_window = self._show_window(
            TrainingWindow, self.training_window, self)

    def load_testing_data(self):
        if self.training_window.lbp_top_X_test_origin is not None:
            test_data_set = self.training_window.lbp_top_X_test_origin
            self.video_list.update_list_from_data_frame(test_data_set)
    
    def get_current_model(self):
        return self.training_window.lbp_top_svm_model

    def update_seekbar(self, value, to):
        self.seekbar['to'] = to
        self.seekbar.set(value)

    def update_progress_bar(self, current, max):
        progress_value = ceil(current * 100 / max)
        self.progress_bar['value'] = progress_value
        self.window.update_idletasks()
