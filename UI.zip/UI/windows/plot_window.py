from tkinter import Toplevel

from ui.components.plot_canvas import PlotCanvas

class PlotWindow(Toplevel):
    def __init__(self, master):
        super().__init__(master=master)
        self.init_gui_elements()
        self.layout_gui()

    def init_gui_elements(self):
        self.plot_canvas = PlotCanvas(self)

    def layout_gui(self):
        self.plot_canvas.get_tk_widget().pack()