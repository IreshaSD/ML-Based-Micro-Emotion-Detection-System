from tkinter import Toplevel

from ui.components.testing_video_canvas import TestingVideoCanvas
from ui.components.testing_video_list import TestingVideoList


class TestingWindow(Toplevel):
    def __init__(self, master, app_instance):
        super().__init__(master=master)
        self.app_instance = app_instance
        self.test_data_set = self.app_instance.training_window.lbp_top_X_test_origin
        self.init_guy_elements()
        self.layout_guy()

    def init_guy_elements(self):
        self.video_canvas = TestingVideoCanvas(self)
        self.video_list = TestingVideoList(self)

    def layout_guy(self):
        self.video_canvas.grid(row=0, column=1)
        self.video_list.grid(row=0, column=0)
