from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class TimelinePlotCanvas(FigureCanvasTkAgg):
	def __init__(self, window):
		self.figure = Figure(figsize=(19, 9), dpi=100)
		self.plot = self.figure.add_subplot(111)
		super().__init__(self.figure, master = window)
		self.draw()

	def plot_line(self, points):
		self.plot.cla()
		self.plot.plot(range(len(points)), points)
		self.draw()
	
	def plot_vline(self, x):
		self.plot.axvline(x=x, color="red")
		self.draw()