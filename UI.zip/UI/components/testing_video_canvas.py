import tkinter
import PIL.Image
import PIL.ImageTk
import cv2


class TestingVideoCanvas(tkinter.Canvas):
    def __init__(self, window):
        super().__init__(window, width=640, height=480)

        self.video_capture = None
        # self.video_capture.buffer_frames()
        self.show_sample_frame()
        self.delay = 15
        self.state = TestingVideoCanvas.STATE_PAUSE

    def play(self):
        if self.state == TestingVideoCanvas.STATE_PLAY:
            self.draw_current_frame(True)
            self.after(self.delay, self.play)

    def play_pause(self):
        self.state = not self.state
        if self.state == TestingVideoCanvas.STATE_PLAY:
            print("Started playing video..")
        else:
            print("Stopped playing video!")
        self.play()

    def seek(self, position):
        self.state = TestingVideoCanvas.STATE_PAUSE
        self.video_capture.current_frame = int(position)
        self.draw_current_frame()

    def draw_current_frame(self, progress=False):
        frame = self.video_capture.get_frame_by_index(
            self.video_capture.current_frame, True)
        face_coordinates = self.video_capture.get_face_coordinates_by_index(
            self.video_capture.current_frame)
        # Draw face rectangle
        cv2.rectangle(frame, tuple(face_coordinates[0]), tuple(face_coordinates[1]), 2)
        self.photo = PIL.ImageTk.PhotoImage(image=PIL.Image.fromarray(frame))
        self.create_image(0, 0, image=self.photo, anchor=tkinter.NW)

        if progress:
            self.video_capture.current_frame += 1
            self.video_capture.current_frame %= self.video_capture.frame_count

    def show_sample_frame(self):
        self.photo = PIL.ImageTk.PhotoImage(
            image=PIL.Image.new('L', (640, 480)))
        self.create_image(0, 0, image=self.photo, anchor=tkinter.NW)
    

    STATE_PLAY = True
    STATE_PAUSE = False