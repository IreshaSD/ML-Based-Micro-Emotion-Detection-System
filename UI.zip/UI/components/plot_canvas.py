from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import time


class PlotCanvas(FigureCanvasTkAgg):
    def __init__(self, window):
        self.figure = Figure(figsize=(5, 5), dpi=100)
        self.plot = self.figure.add_subplot(111)
        super().__init__(self.figure, master = window)
        self.draw()

    def update_plot(self, plot_type, video_capture):
        if plot_type == PlotCanvas.PLOT_TYPE_LBP_HIST:
            lbp_hist = video_capture.get_lbp_hist()
            self.hist(lbp_hist)
        elif plot_type == PlotCanvas.PLOT_TYPE_LBP_TOP_HIST:
            start_time = time.time()
            lbp_top_hist = video_capture.get_lbp_top_hist()
            self.create_or_update_bar_chart(lbp_top_hist)
            print("--- %s seconds ---" % (time.time() - start_time))
        self.draw()

    
    def plot_line(self, line_data):
        pass

    def create_or_update_bar_chart(self, values):
        self.plot.cla()
        return self.plot.bar(range(len(values)), values)
    
    def hist(self, lbp_hist):
        n_bins = int(lbp_hist.max() + 1)
        self.plot.cla()
        return self.plot.hist(
            lbp_hist,
            density=True,
            bins=n_bins,
            range=(0, n_bins),
            facecolor="0.5",
        )
    
    PLOT_TYPE_LBP_HIST = 0
    PLOT_TYPE_LBP_TOP_HIST = 1