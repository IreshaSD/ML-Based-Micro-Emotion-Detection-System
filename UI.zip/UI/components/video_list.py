from tkinter import Listbox
import pandas as pd
import os


class VideoList(Listbox):
    def __init__(self, window, base_path,  csv_file_path):
        super().__init__(window, height=50)
        self.csv_file_path = csv_file_path
        self.base_path = base_path
        self.data_frame = None
        self.load_csv()
    
    def update_list_from_data_frame(self, data_frame):
        self.data_frame = data_frame.reset_index(drop=True)
        self.delete(0, 'end')
        for index, row in data_frame.iterrows():
            self.insert(index, f"{row['Subject']}_{row['Filename']}")

    def load_csv(self):
        self.data_frame = pd.read_csv(self.csv_file_path)
        self.update_list_from_data_frame(self.data_frame)
    
    def select_item_by_index(self, index):
        self.selection_clear(0, self.data_frame.shape[0] - 1)
        self.selection_set(index, index)
        self.activate(index)
        self.see(index)

    def _get_current_item(self):
        current_index = self.curselection()[0]
        current_row = self.data_frame.loc[current_index].to_dict()
        return current_row

    def get_video_path(self):
        current_item = self._get_current_item()
        file_path = os.path.join(self.base_path, current_item['Subject'], current_item['Filename'] + '.avi')
        return file_path

    def get_current_item(self):
        current_item = self._get_current_item()
        current_item_file_path = self.get_video_path()
        current_item["path"] = current_item_file_path
        return current_item
