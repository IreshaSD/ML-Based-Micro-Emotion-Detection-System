from pandas.core.frame import DataFrame
from ui.components.video_list import VideoList


class TestingVideoList(VideoList):
    def __init__(self, window, data_frame):
        self.data_frame: DataFrame = data_frame
        self.data_frame.columns = ['Subject', 'Filename', 'OnsetFrame', 'ApexFrame', 'OffsetFrame', 'Estimated Emotion']