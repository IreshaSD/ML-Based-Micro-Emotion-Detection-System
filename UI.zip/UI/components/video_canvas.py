import tkinter
import PIL.Image
import PIL.ImageTk
import cv2


class VideoCanvas(tkinter.Canvas):
    def __init__(self, window):
        super().__init__(window, width=640, height=480)

        self.video_capture = None
        # self.video_capture.buffer_frames()
        self.show_sample_frame()
        self.delay = 1
        self.state = VideoCanvas.STATE_PAUSE

    def play(self):
        if self.state == VideoCanvas.STATE_PLAY:
            self.draw_current_frame(True)
            self.after(self.delay, self.play)

    def play_pause(self):
        self.state = not self.state
        if self.state == VideoCanvas.STATE_PLAY:
            print("Started playing video..")
        else:
            print("Stopped playing video!")
        self.play()

    def seek(self, position):
        self.state = VideoCanvas.STATE_PAUSE
        self.video_capture.current_frame = int(position)
        self.draw_current_frame()

    def draw_current_frame(self, progress=False):
        frame = self.video_capture.get_frame_by_index(
            self.video_capture.current_frame, True)
        face_coordinates = self.video_capture.get_face_coordinates_by_index(
            self.video_capture.current_frame)
        # Draw face rectangle
        cv2.rectangle(frame, tuple(face_coordinates[0]), tuple(face_coordinates[1]), 2)
        self.overlay_frame_number(frame)

        if self.video_capture.test_results is not None:
            self.show_prediction(frame)

        self.photo = PIL.ImageTk.PhotoImage(image=PIL.Image.fromarray(frame))
        self.create_image(0, 0, image=self.photo, anchor=tkinter.NW)

        if progress:
            self.video_capture.current_frame += 1
            self.video_capture.current_frame %= self.video_capture.frame_count

    def show_sample_frame(self):
        self.photo = PIL.ImageTk.PhotoImage(
            image=PIL.Image.new('L', (640, 480)))
        self.create_image(0, 0, image=self.photo, anchor=tkinter.NW)
    
    def overlay_frame_number(self, frame):
        cv2.putText(frame, str(int(self.video_capture.current_frame)), (7, 70),
                    cv2.FONT_HERSHEY_SIMPLEX, 3, (100, 255, 0), 3, cv2.LINE_AA)

    def show_prediction(self, frame):
        current_prediction = self.video_capture.test_results[self.video_capture.current_frame]
        cv2.putText(frame, str(current_prediction), (200, 70),
                    cv2.FONT_HERSHEY_SIMPLEX, 3, (100, 255, 0), 3, cv2.LINE_AA)

    STATE_PLAY = True
    STATE_PAUSE = False